from flask import Flask,render_template,request,redirect
from flask_sqlalchemy import SQLAlchemy
import os
from datetime import datetime,timedelta
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sqlalchemy import func
import pandas as pd

current_dir=os.path.abspath(os.path.dirname(__file__))
URI="sqlite:///"+os.path.join(current_dir,"database.db")
app=Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = URI
db=SQLAlchemy()
db.init_app(app)
app.app_context().push()

#models
class ToDo(db.Model):
    __tablename__ = 'ToDo'
    
    ListID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    Name = db.Column(db.String(255), nullable=False)
    Description = db.Column(db.Text, nullable=False)
    StartDate = db.Column(db.Date, nullable=False)
    FinishDate = db.Column(db.Date)
    DueDate = db.Column(db.Date)
    Category = db.Column(db.String(255), nullable=False)
    Subject = db.Column(db.String(255), nullable=False)
    Topic = db.Column(db.String(255))
    Status = db.Column(db.String(20), nullable=False)
    Result = db.Column(db.Integer)
    Feedback = db.Column(db.Text)
    Remarks = db.Column(db.Text)

    __table_args__=(
        db.CheckConstraint("Status IN ('Pending', 'Submitted','Due Date Passed','Cancelled')", name='check_status'),
    )

#Controllers
today=datetime.today().date()

#Functions
def up_assign(num_periods,days_per_period):
    counts = {}
    todos=db.session.query(ToDo).filter(ToDo.DueDate<=today+timedelta(days=num_periods*days_per_period),ToDo.Status=='Pending').all()
    for i in range(num_periods):
        start_of_week = today + timedelta(days=i * days_per_period)
        end_of_week = today + timedelta(days=(i + 1) * days_per_period - 1)
        count = sum(start_of_week <= todo.DueDate <= end_of_week for todo in todos)
        counts[f'{start_of_week.strftime("%d-%m")}  to  {end_of_week.strftime("%d-%m")}'] = count
    return counts

def past_assign(num_periods, days_per_period):
    counts = {}
    todos = db.session.query(ToDo).filter(ToDo.DueDate <= today, ToDo.Status == 'Submitted').all()
    for i in range(num_periods):
        start_of_week = today - timedelta(days=(i + 1) * days_per_period - 1)
        end_of_week = today - timedelta(days=i * days_per_period)
        count = sum(start_of_week <= todo.FinishDate <= end_of_week for todo in todos)
        counts[f'{start_of_week.strftime("%d-%m")} to {end_of_week.strftime("%d-%m")}'] = count
    return dict(reversed(counts.items()))

def path(link):
    image_path = 'static/images'
    abs_path = os.path.abspath(image_path)
    full_path = os.path.join(abs_path, link)
    return full_path

def plot_bar(dict,title):
    labels=list(dict.keys())
    values=list(dict.values())

    plt.figure(figsize=(10, 6))
    plt.bar(labels, values, color='darkblue')
    plt.xticks(rotation=45, ha='right')
    plt.xlabel('Week Range')
    plt.ylabel('Number of Assignments')
    plt.title(title)
    plt.tight_layout()
    plt.savefig(path(f'Dashboard/{title}.jpg'))
    plt.close()

@app.route('/Dashboard',methods=['GET'])
def Dashboard():
    todays=(db.session.query(ToDo)
              .filter(ToDo.Status=='Pending',ToDo.DueDate==today)
              .all())
    tomos=(db.session.query(ToDo)
           .filter(ToDo.Status=='Pending',ToDo.DueDate==today+timedelta(days=1))
           .all())
    due=db.session.query(ToDo).filter(ToDo.Status=='Pending',ToDo.DueDate<today).all()
    for i in due:
        i.Status='Due Date Passed'
        i.Result=0
        i.Feedback='Auto Failure'
        db.session.commit()
    
    up=up_assign(7,2)  
    past=past_assign(7,2)

    plot_bar(up,'Upcoming Assignments')
    plot_bar(past,'Past Assigments')
    return render_template('Dashboard.html',todays=todays,tomos=tomos,due=due)

@app.route('/Pending',methods=["GET"])
def Pending():
    pending=(db.session.query(ToDo)
             .filter(ToDo.Status=='Pending')
             .order_by(ToDo.DueDate)
             .all())
    return render_template('Pending.html',pending=pending)

@app.route('/Completed',methods=['GET'])
def Completed():
    completed=(db.session.query(ToDo)
               .filter(ToDo.Status=='Submitted' )
               .order_by(ToDo.FinishDate.desc())
               .all())
    return render_template('Completed.html',completed=completed)

@app.route('/Failed',methods=['GET'])
def Failed():
    failed=(db.session.query(ToDo).filter(ToDo.Status=='Due Date Passed' )
            .order_by(ToDo.DueDate.desc())
            .all())
    return render_template('Failed.html',failed=failed)

@app.route('/Cancelled',methods=['GET'])
def Cancelled():
    cancelled=(db.session.query(ToDo).filter(ToDo.Status=='Cancelled' )
               .order_by(ToDo.DueDate.desc())
               .all())
    return render_template('Cancelled.html',cancelled=cancelled)

@app.route('/All',methods=["GET"])
def All():
    all=(db.session.query(ToDo)
         .order_by(ToDo.DueDate.desc())
         .all())
    return render_template('All.html',all=all)

@app.route('/Details/<int:ListID>',methods=['GET'])
def Details(ListID):
    assign=db.session.query(ToDo).filter(ToDo.ListID==ListID).one()
    return render_template('Details.html',assign=assign)

@app.route('/Create',methods=['GET','POST'])
def Create():
    if request.method=='POST':
        name=request.form['name']
        description=request.form['description']
        duedate = datetime.strptime(request.form['duedate'], '%Y-%m-%d').date()
        category=request.form['category']
        subject=request.form['subject']
        topic=request.form['topic']
        remarks=request.form['remarks']

        new_assign=ToDo(
            Name=name,
            Description=description,
            StartDate=today,
            DueDate=duedate,
            Category=category,
            Subject=subject,
            Topic=topic,
            Remarks=remarks,
            Status='Pending'
        )
        db.session.add(new_assign)
        db.session.commit()
        return redirect(f'/Details/{new_assign.ListID}')
    return render_template('Create.html',today=today)

@app.route('/Submit/<int:ListID>',methods=['GET','POST'])
def Submit(ListID):
    assign=db.session.query(ToDo).filter(ToDo.ListID==ListID).one()
    if request.method=='POST':
        assign.FinishDate=today
        assign.Status='Submitted'
        assign.Result=request.form['result']
        assign.Feedback=request.form['feedback']
        db.session.commit()
        return redirect(f'/Details/{ListID}')
    return render_template('Submit.html',assign=assign)

@app.route('/Edit/<int:ListID>',methods=["GET",'POST'])
def Edit(ListID):
    assign=db.session.query(ToDo).filter(ToDo.ListID==ListID).one()
    if request.method=='POST':
        assign.Description=request.form['description']
        assign.DueDate=datetime.strptime(request.form['duedate'], '%Y-%m-%d').date()
        assign.Category=request.form['category']
        assign.Subject=request.form['subject']
        assign.Topic=request.form['topic']
        assign.Remarks=request.form['remarks']
        assign.Status='Pending'
        db.session.commit()
        return redirect(f'/Details/{ListID}')
    return render_template('Edit.html',assign=assign,today=today)

@app.route('/Cancel/<int:ListID>',methods=["GET",'POST'])
def Cancel(ListID):
    assign=db.session.query(ToDo).filter(ToDo.ListID==ListID).one()
    if request.method=='POST':
        assign.Feedback=request.form['feedback']
        assign.Status='Cancelled'
        db.session.commit()
        return redirect(f'/Details/{ListID}')
    return render_template('Cancel.html',assign=assign)

@app.route('/Feedback/<int:ListID>',methods=["GET",'POST'])
def Feedback(ListID):
    assign=db.session.query(ToDo).filter(ToDo.ListID==ListID).one()
    if request.method=='POST':
        assign.Result=request.form['result']
        assign.Feedback=request.form['feedback']
        db.session.commit()
        return redirect(f'/Details/{ListID}')
    return render_template('Feedback.html',assign=assign)

@app.route('/Category',methods=['GET'])
def Category():
    categories = (db.session.query(ToDo.Category,func.count(ToDo.Category).label('count'))
                       .group_by(ToDo.Category)
                       .order_by(func.count(ToDo.Category).desc())
                       .all())
    return render_template('By_Category.html',categories=categories)

@app.route('/Cat_assign/<string:Category>',methods=['GET'])
def Cat_Assign(Category):
    assign=db.session.query(ToDo).filter(ToDo.Category==Category).order_by(ToDo.DueDate.desc()).all()
    return render_template('Category.html',Category=Category,assign=assign)



if __name__=='__main__':
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )


