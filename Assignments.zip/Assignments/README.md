ASSIGNMENTS APP:
This app is designed to help you keep track of your completed and upcoming assignments along with their results.

Usage Instructions:
    STEP 1: Open PowerShell
        Open Windows PowerShell and navigate to the folder where the Assignments app is downloaded.
    STEP 2: Run the Installation Script
        Run the following command to begin the installation process:
        Copy code
        & "C:\Program Files\Git\bin\bash.exe" --login -i "./installation.sh"
    Step 3: Start the Application
        After the installation is complete, start the application by running:
        Copy code
        & "C:\Program Files\Git\bin\bash.exe" --login -i "./app_run.sh"

The app will open in a new window and be ready for use.

Requirements:
    Python: Ensure that Python is installed and properly configured on your system.
    Git Bash: Make sure Git Bash is installed on your system.
    pip: The Python package manager pip needs to be working correctly for the app to install dependencies.

Also, I have added some dummy entries just to make the app look real.
Feel free to delete them: 
    Open ./project/database with a database tool and delete all entries
    
Enjoy using the app!