#!/bin/bash
scriptPath=$(dirname "$0")
cd "$scriptPath"
source Venv/Scripts/activate
cd Project
flask run & sleep 3
"/c/Program Files/Google/Chrome/Application/chrome.exe" --new-window http://localhost:5000/Dashboard
