#!/bin/bash

scriptPath=$(dirname "$0")
cd "$scriptPath"

# Delete existing virtual environment if it exists
if [ -d "Venv" ]; then
    echo "Deleting old virtual environment..."
    rm -rf Venv
fi

# Create a new virtual environment
echo "Creating a new virtual environment..."
python -m venv Venv

# Activate the virtual environment
echo "Activating virtual environment..."
source Venv/Scripts/activate

# Install dependencies from requirements.txt
cd Project
pip install --no-cache-dir -r requirements.txt
echo "Installation successful"
